//
//  SelectionViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/12/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class SelectionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
 
    var nuevaCita = [OpAgenda] ()
    var seleccionado : menu!
    var  cita = OpAgenda(dia: 0, fecha: "", hora: "", disponible: true)

    
    @IBOutlet weak var tablita2: UITableView!
    
    @IBOutlet weak var mes: UILabel!
    
    @IBOutlet weak var calendario: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//       nuevaCita.append(OpAgenda(fecha: "", hora: "", disponible: 0))
        nuevaCita.append(OpAgenda(dia:11 ,fecha:"lunes",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:12 ,fecha:"martes",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:13 , fecha:"miércoles ",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:14 , fecha:"jueves ",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:15 , fecha:"viernes ",hora:"13:00",disponible:true))
    
        
        let date = Date ()
        
        print(date)
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = .medium
       // dateFormatter.timeStyle = .medium
        
        print(dateFormatter.string(from: date))
        
        mes.text = dateFormatter.string(from: date)
        
        let DM = OpAgenda.init(dia: 16, fecha: "domingo", hora: "22:00", disponible: true)
        

    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if seleccionado.nombre == "Agenda" {
         
              return nuevaCita.count
            
        } else {
            return 0
        }
 
    
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "celda2", for:indexPath)
    cell.textLabel?.text = "\(nuevaCita[indexPath.row].fecha) - \(nuevaCita[indexPath.row].hora)"
   
    return cell
    
    
    
    }
    
    
    
func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
    
    let marcarCita = UIContextualAction (style: .normal, title: "Confirmar") { (action, sourceview, completion) in
        
        self.cita = OpAgenda.init(dia: self.cita.dia, fecha: "\(self.cita.fecha)" , hora: "\(self.cita.hora)", disponible: false)
        print(self.cita)
        print(self.cita.disponible)
    //
      self.calendario.reloadData()
        
        self.seleccionado.fecha = self.seleccionado.fecha + 1
        
 //       print(self.seleccionado)
        
        
        
    }
    
    
    let cancelarCita = UIContextualAction (style: .destructive, title: "Cancelar") { (action, sourceview, completion) in
        
        let cita2 = OpAgenda.init(dia: self.cita.dia, fecha: "\(self.cita.fecha)" , hora: "\(self.cita.hora)", disponible: true)
        print(cita2)
        print("-----------\(cita2.dia)-----------")
//        print(cell)
    
        
        
    }
    
    let swipeCongiration = UISwipeActionsConfiguration (actions: [marcarCita, cancelarCita])
    
    return swipeCongiration
    
    }
   /*  let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, sourceview, completion) in
     
     self.alumnos.remove(at: indexPath.row)
     
     self.tablita.deleteRows(at: [indexPath], with: .fade )
     
     
     completion(true)
     
     }
     
     let shareAction = UIContextualAction(style: .normal, title: "Share") { (action, sourceview, completion) in
     
     
     }
     
     let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction, shareAction])
     
     return swipeConfiguration
     
     }
 
     
     
     
     
 */
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 31
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "item", for: indexPath) as! ItemCollectionViewCell
        
        cell.dias.text = "\(indexPath.item + 1)"
        cell.backgroundColor = UIColor.blue
        
     //   print(indexPath)
     //   print(IndexPath())
     //   print(indexPath.row)
       // print("_____", calendario.indexPathsForSelectedItems)
        
       // var indice = calendario.indexPathsForSelectedItems
        
                
        if cell.dias.text == String(cita.dia)  {

      cell.backgroundColor = UIColor.purple

      }

       //print("----\(indice)------------------------")
        
        return cell
        
        
        
    }
    
    

}
