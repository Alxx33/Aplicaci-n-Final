//
//  Datos.swift
//  proyecto2A1
//
//  Created by Laboratorio UNAM-Apple 04 on 12/10/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import Foundation

struct datos {
    
    var nombre: String
    var pw: String
    
}
