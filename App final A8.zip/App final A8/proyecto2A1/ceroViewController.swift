//
//  ceroViewController.swift
//  proyecto2A1
//
//  Created by Laboratorio UNAM-Apple 04 on 04/12/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ceroViewController: UIViewController {
    @IBOutlet weak var icono: UIImageView!
    
    @IBOutlet weak var claveempresa: UITextField!
   
    @IBAction func confirmar(_ sender: UIButton) {
        let refer = Database.database().reference()
        
        refer.childByAutoId().setValue(["empresa": registroempresa.text!, "clave": claveempresa.text!])
        
    }
    @IBOutlet weak var registroempresa: UITextField!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
icono.image = UIImage(named: "Image")
    }



}
