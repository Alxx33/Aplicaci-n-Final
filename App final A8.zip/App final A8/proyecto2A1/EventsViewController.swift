//
//  EventsViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import FirebaseDatabase
import Firebase


class EventsViewController: UIViewController {
    
    
    var arreglo = [String]()
    
    
    
    @IBAction func Ver(_ sender: UIButton) {
        
        Eanteriores.text = arreglo [1]
        
    }
    
    
    @IBOutlet weak var Eanteriores: UILabel!
    
    
    @IBOutlet weak var eventoNom: UITextField!
    
    @IBOutlet weak var EventoEvent: UITextField!
    
    
    @IBOutlet weak var EventoFecha: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard
        
        arreglo = defaults.object(forKey: "arreglo") as? [String] ?? [String] ()
        
        
    }
    @IBAction func PR(_ sender: UIButton) {
        
        
 /*       Firestore.firestore().collection("Eventos").addDocument(data: ["nombre": eventoNom.text!, "nombreE": EventoEvent.text!, "fecha": EventoFecha.text! ]){(error) in
            if let error = error{
                debugPrint(error)
            }else{
                self.navigationController?.popViewController(animated: true)
            }
        } */
   
        
        let defaults = UserDefaults.standard
        let nombre = eventoNom.text
        let nomEvent = EventoEvent.text
        
        arreglo.append(nombre!)
        
        defaults.set(arreglo, forKey: "arreglo")
        print(arreglo)
        
//        contraseñas.append(password!)
 //       defaults.set(contraseñas, forKey: "contraseñas")
  //      print(contraseñas)
    
        
        
        
     
        
        
        
        
        
    let ref = Database.database().reference()
        
        ref.childByAutoId().setValue(["nom":eventoNom.text!, "nomEvento":EventoEvent.text!, "fecha": EventoFecha.text!])
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Dest2ThirdViewController : ThirdViewController = segue.destination as! ThirdViewController
        
        Dest2ThirdViewController.campo1 = eventoNom.text!
        Dest2ThirdViewController.campo2 = EventoEvent.text!
        Dest2ThirdViewController.campo3 = EventoFecha.text!
        Dest2ThirdViewController.arreglo = arreglo
        
     
    }
    
    
    
    
    
}
