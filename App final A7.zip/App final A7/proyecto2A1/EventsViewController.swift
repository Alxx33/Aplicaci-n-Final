//
//  EventsViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import FirebaseDatabase


class EventsViewController: UIViewController {
    
    
    var arreglo = [String]()
    
    @IBOutlet weak var eventoNom: UITextField!
    
    @IBOutlet weak var EventoEvent: UITextField!
    
    
    @IBOutlet weak var EventoFecha: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let defaults = UserDefaults.standard
        
        arreglo = defaults.object(forKey: "arreglo") as? [String] ?? [String] ()
        
        
    }
    @IBAction func PR(_ sender: UIButton) {
        
        let evnt = eventoNom.text
        
        arreglo.append(evnt!)
   
        
        let defaults = UserDefaults.standard
        
        
        defaults.set(arreglo, value(forKey: "arreglo"))
        
        
        arreglo = defaults.object(forKey: "arreglo") as? [String] ?? [String] ()
        
        if let dato = eventoNom.text{
            defaults.set(dato, forKey: "EventoNom")
        }
        
        if let dato = EventoEvent.text{
            defaults.set(dato, forKey: "EventoEvent")
        }
        
        if let dato = EventoFecha.text{
            defaults.set(dato, forKey: "EventoFecha")
        }
        
        
        
        
        
    let ref = Database.database().reference()
        
        ref.childByAutoId().setValue(["nom":eventoNom.text!, "nomEvento":EventoEvent.text!, "fecha": EventoFecha.text!])
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Dest2ThirdViewController : ThirdViewController = segue.destination as! ThirdViewController
        
        Dest2ThirdViewController.campo1 = eventoNom.text!
        Dest2ThirdViewController.campo2 = EventoEvent.text!
        Dest2ThirdViewController.campo3 = EventoFecha.text!
        
    }
    
    
}
