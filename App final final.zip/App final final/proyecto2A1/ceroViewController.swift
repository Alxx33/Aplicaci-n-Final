//
//  ceroViewController.swift
//  proyecto2A1
//
//  Created by Laboratorio UNAM-Apple 04 on 04/12/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ceroViewController: UIViewController {
    
    var empresasRegistradas = [String] ()
    var contraseñasEmpresas = [String] ()
 
    @IBOutlet weak var icono: UIImageView!
    
    @IBOutlet weak var claveempresa: UITextField!
   
    @IBAction func confirmar(_ sender: UIButton) {
    
        let refer = Database.database().reference()
        let defaults = UserDefaults.standard
        let empresaNom = registroempresa.text
        let empresaContra = claveempresa.text
        
        refer.childByAutoId().setValue(["empresa": registroempresa.text!, "clave": claveempresa.text!])
        
   
        
        empresasRegistradas.append(empresaNom!)
        contraseñasEmpresas.append(empresaContra!)
        
        
        
        defaults.set(empresasRegistradas, forKey: "empresasRegistradas")
        defaults.set(contraseñasEmpresas, forKey: "contraseñasEmpresas")
        
        
        print(empresasRegistradas)
        print(contraseñasEmpresas)
        
        
        
    }
    @IBOutlet weak var registroempresa: UITextField!
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
icono.image = UIImage(named: "Image")
        
        let defaults = UserDefaults.standard
        empresasRegistradas = defaults.object(forKey: "empresasRegistradas") as? [String] ?? [String] ()
        contraseñasEmpresas = defaults.object(forKey: "contraseñasEmpresas") as? [String] ?? [String] ()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino3 : ViewController = segue.destination as! ViewController
        
        destino3.contraseñasEmp = contraseñasEmpresas
        
    }
        



}
