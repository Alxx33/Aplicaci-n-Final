//
//  SelectionViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/12/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class SelectionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
 
    var nuevaCita = [OpAgenda] ()
    var seleccionado : menu!
    var cita = [OpAgenda(dia: 0, fecha: "", hora: "", disponible: true)]
    var numeros = [String] ()
    var lugar = [Int] ()
    var agendado = [String] ()
    
    
    @IBOutlet weak var tablita2: UITableView!
    
    @IBOutlet weak var mes: UILabel!
    
    @IBOutlet weak var calendario: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//       nuevaCita.append(OpAgenda(fecha: "", hora: "", disponible: 0))
        nuevaCita.append(OpAgenda(dia:0 ,fecha:" ",hora:" ",disponible:true))
        nuevaCita.append(OpAgenda(dia:1 ,fecha:"sabado 1",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:2 , fecha:"domingo 2",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:3 , fecha:"lunes 3",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:4 , fecha:"martes 4",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:5 , fecha:"miércoles 5",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:6 , fecha:"jueves 6",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:7 , fecha:"jueves 7",hora:"13:00",disponible:true))
    
        
        let date = Date ()
        
        print(date)
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = .medium
       // dateFormatter.timeStyle = .medium
        
        print(dateFormatter.string(from: date))
        
        mes.text = dateFormatter.string(from: date)
        
//        let DM = OpAgenda.init(dia: 16, fecha: "domingo", hora: "22:00", disponible: true)
        
      let defaults = UserDefaults.standard
        
        defaults.set (agendado, forKey: "agendado")
        

    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nuevaCita.count
    
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "celda2", for:indexPath)
    cell.textLabel?.text = "\(nuevaCita[indexPath.row].fecha) - \(nuevaCita[indexPath.row].hora)"
   
    return cell
    
    
    
    }
    
    
    
func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
    
    let marcarCita = UIContextualAction (style: .normal, title: "Confirmar") { (action, sourceview, completion) in
        
        for e in 0...self.cita.count - 1 {
            self.cita[e] = OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: false )
             print(self.cita[e])
        }
            ///--------
        self.lugar.append(indexPath.row)
        //------
     //           print(self.cita[e]))
            
        
        
        
        
 //       self.cita = [OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: false )]
   
//        print(self.cita.disponible)
    //
      self.calendario.reloadData()
        
        
    }
    
    
    let cancelarCita = UIContextualAction (style: .destructive, title: "Cancelar") { (action, sourceview, completion) in
        
        for e in 0...self.cita.count - 1 {
            self.cita[e] = OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: true )
            print(self.cita[e])
        }
        
   //     self.cita = [OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: true )]
        print(self.cita)
//        print("-----------\(cita2.dia)-----------")
//        print(cell)
        //self.lugar.remove(where: indexPath.row)
        
        if self.lugar.count > 0 {
        var cont2 = 0
        var cont3 = 0
        for tn in self.lugar{
            if(tn == indexPath.row){
                cont2 = cont3
            }else{
                 cont2 = cont2 + 1
            }
           
        }
            
       print(self.lugar)
        print(cont3)
       self.lugar.remove(at: cont3)
        print(self.lugar)
        
       self.calendario.reloadData()
        }
        
    }
    
    let swipeCongiration = UISwipeActionsConfiguration (actions: [marcarCita, cancelarCita])
    
    return swipeCongiration
    
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 31
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "item", for: indexPath) as! ItemCollectionViewCell
        
        cell.dias.text = "\(indexPath.item + 1)"
        cell.backgroundColor = UIColor.white
        
     //   print(indexPath)
     //   print(IndexPath())
     //   print(indexPath.row)
       // print("_____", calendario.indexPathsForSelectedItems)
        
       // var indice = calendario.indexPathsForSelectedItems
        
        if cita.count > 0 {
            print("---------------")
            print(cita)
            for  tox in lugar {
                if (tox == indexPath.item + 1){
                    print(tox)
                    print(indexPath.item + 1)
                    cell.backgroundColor = UIColor.orange
                }
                
            }
//        for e in 0...cita.count - 1 {
//            if cell.dias.text == String(self.cita[e].dia) {
//                if self.cita[e].disponible == false {
//
//                    cell.backgroundColor = UIColor.orange
//
//                } else {
//                    cell.backgroundColor = UIColor.white
//                }
//
//
//            }
//        }
//
        }
 /*       if cell.dias.text == self.cita.dia  {
            
            if cita.disponible == false {

      cell.backgroundColor = UIColor.orange
                
            } else {
                 cell.backgroundColor = UIColor.white
            }

      } */

        
        return cell
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        let agenda : ThirdViewController = segue.destination as! ThirdViewController
        
        
 //       agenda.seleccion = agendado
        
        
    }


}
