//
//  UltimViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 12/6/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class UltimViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    var eventos = [String] ()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
            print (eventos)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return eventos.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ultimo", for:indexPath)
        cell.textLabel?.text = "\(eventos[indexPath.row]) "
        
        return cell
    }
    
        
        
    }


