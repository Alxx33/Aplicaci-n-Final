//
//  EventsViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import FirebaseDatabase


class EventsViewController: UIViewController {
    
    
    @IBOutlet weak var eventoNom: UITextField!
    
    @IBOutlet weak var EventoEvent: UITextField!
    
    
    @IBOutlet weak var EventoFecha: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()        
        
        
    }
    @IBAction func PR(_ sender: UIButton) {
        
        let ref = Database.database().reference()
        
        //       ref.child("someid/name").setValue("Mike")
        
        ref.childByAutoId().setValue(["nom":eventoNom.text!, "nomEvento":EventoEvent.text!,"fecha":EventoFecha.text!])
        
        
  //      print(Nomevento)
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Dest2ThirdViewController : ThirdViewController = segue.destination as! ThirdViewController
        
        Dest2ThirdViewController.campo1 = eventoNom.text!
        Dest2ThirdViewController.campo2 = EventoEvent.text!
        Dest2ThirdViewController.campo3 = EventoFecha.text!
        
    }
    
    
}
