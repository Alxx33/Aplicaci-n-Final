//
//  ThirdViewController.swift
//  proyecto2A1
//
//  Created by Alejandro Barron Solis, Isaac Hernandez Loredo.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase



class ThirdViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    var ref: DatabaseReference!
    var handle : AuthStateDidChangeListenerHandle?
    var databaseHandle: DatabaseHandle?
    let use = Auth.auth().currentUser
    var eventosGuardados = [String] ()
   
    
    
 //   ref = Database.database().reference()
 

    @IBOutlet weak var nomusuario: UILabel!
    
    @IBOutlet weak var Publicacion: UITextView!
    
    @IBOutlet weak var ImAgenda: UIImageView!
    
    @IBOutlet weak var ImCrono: UIImageView!
    
    @IBOutlet weak var ImEventos: UIImageView!
    
    @IBOutlet weak var ImUbicaciòn: UIImageView!
    
    @IBOutlet weak var tabEventos: UITableView!
    
    

    
    var x = [menu] ()
    var sobrantes = ["Eventos"]
    var campo1 = String ()
    var campo2 = String ()
    var campo3 = String ()
    
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabEventos.delegate = self
        tabEventos.dataSource = self
        
        
        ImAgenda.image = UIImage(named: "agenda")
        ImCrono.image = UIImage(named: "cronograma")
        ImUbicaciòn.image = UIImage(named: "ubicacion")
       

        if campo1 == "" {
            
            Publicacion.text = nil
            
        } else {
            
             Publicacion.text = "    De:   \(campo1) , asunto: \(campo2)  fecha: \(campo3) "
            
        }

        nomusuario.text = use?.displayName
        
      ref = Database.database().reference()
        
       databaseHandle = ref?.child("someid").observe(DataEventType.value, with: { (snapshot) in
        
            
            
        var post = snapshot.value as? [String: AnyObject] ?? [:]
            
        if var actualPost = post {
        
 //       let postDict = snapshot.value as? [String : AnyObject] ?? [:]
                self.eventosGuardados.append(actualPost)
                
     //           self.tabEventos.reloadData()
            }
        })
        
        
 //       databaseHandle = ref.observe(DataEventType.value, with: {(snapshot) in
      //    self.eventosGuardados.append("")
  //      })
        // refHandle = postRef.observe(DataEventType.value, with: { (snapshot) in
    //    let postDict = snapshot.value as? [String : AnyObject] ?? [:]
        
  //      let post = snapshot.value as? String
        
//        if let actualPost  {
        
 //       }

}
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return eventosGuardados.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "eventoTabla", for: indexPath)
        cell.textLabel?.text = eventosGuardados[indexPath.row]
        cell.backgroundColor = UIColor.cyan
        
        return cell

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        handle = Auth.auth().addStateDidChangeListener{ (auth, use) in
    }
    
   
    }
}
