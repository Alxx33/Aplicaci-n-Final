//
//  ItemCollectionViewCell.swift
//  proyecto2A1
//
//  Created by Macbook on 11/26/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class ItemCollectionViewCell: UICollectionViewCell {
 
    @IBOutlet weak var dias: UILabel!
    
    
}
