//
//  Datos.swift
//  proyecto2A1
//
//  Created by Alejandro Barron Solis, Isaac Hernandez Loredo.
//  Copyright © 2018 unam fca. All rights reserved.
//

import Foundation

struct datos {
    var nombre: String
    var pw: String
}


struct menu {
    var nombre: String
    var imagen: String
    var fecha: Int
}


struct OpAgenda
{
    var dia: Int
    var fecha: String
    var hora: String
    var disponible: Bool
    
}
