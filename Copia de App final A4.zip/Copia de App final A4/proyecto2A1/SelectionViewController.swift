//
//  SelectionViewController.swift
//  proyecto2A1
//
//  Created by Macbook on 11/12/18.
//  Copyright © 2018 unam fca. All rights reserved.
//

import UIKit

class SelectionViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UICollectionViewDataSource, UICollectionViewDelegate {
    
 
    var nuevaCita = [OpAgenda] ()
    var seleccionado : menu!
    var  cita = OpAgenda(dia: 0, fecha: "", hora: "", disponible: true)

    
    @IBOutlet weak var tablita2: UITableView!
    
    @IBOutlet weak var mes: UILabel!
    
    @IBOutlet weak var calendario: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//       nuevaCita.append(OpAgenda(fecha: "", hora: "", disponible: 0))
        nuevaCita.append(OpAgenda(dia:11 ,fecha:"lunes 11",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:12 ,fecha:"martes 12",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:13 , fecha:"miércoles 13",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:14 , fecha:"jueves 14",hora:"13:00",disponible:true))
        nuevaCita.append(OpAgenda(dia:15 , fecha:"viernes 15",hora:"13:00",disponible:true))
    
        
        let date = Date ()
        
        print(date)
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateStyle = .medium
       // dateFormatter.timeStyle = .medium
        
        print(dateFormatter.string(from: date))
        
        mes.text = dateFormatter.string(from: date)
        
        let DM = OpAgenda.init(dia: 16, fecha: "domingo", hora: "22:00", disponible: true)
        
      
        

    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nuevaCita.count
    
    }
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "celda2", for:indexPath)
    cell.textLabel?.text = "\(nuevaCita[indexPath.row].fecha) - \(nuevaCita[indexPath.row].hora)"
   
    return cell
    
    
    
    }
    
    
    
func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
    
    
    let marcarCita = UIContextualAction (style: .normal, title: "Confirmar") { (action, sourceview, completion) in
        
self.cita = OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: false )
        print(self.cita)
        print(self.cita.disponible)
    //
      self.calendario.reloadData()
        
        
        
 //       print(self.seleccionado)
        
        
        
    }
    
    
    let cancelarCita = UIContextualAction (style: .destructive, title: "Cancelar") { (action, sourceview, completion) in
        
       self.cita = OpAgenda.init(dia: self.nuevaCita[indexPath.row].dia, fecha: "\(self.nuevaCita[indexPath.row].fecha)" , hora: "\(self.nuevaCita[indexPath.row].hora)", disponible: true )
        print(self.cita)
//        print("-----------\(cita2.dia)-----------")
//        print(cell)
    
       self.calendario.reloadData()
        
    }
    
    let swipeCongiration = UISwipeActionsConfiguration (actions: [marcarCita, cancelarCita])
    
    return swipeCongiration
    
    }
   /*  let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, sourceview, completion) in
     
     self.alumnos.remove(at: indexPath.row)
     
     self.tablita.deleteRows(at: [indexPath], with: .fade )
     
     
     completion(true)
     
     }
     
     let shareAction = UIContextualAction(style: .normal, title: "Share") { (action, sourceview, completion) in
     
     
     }
     
     let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction, shareAction])
     
     return swipeConfiguration
     
     }
 
    
 */
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return nuevaCita.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "item", for: indexPath) as! ItemCollectionViewCell
        
        cell.dias.text = "\(nuevaCita[indexPath.row].dia)"
        cell.backgroundColor = UIColor.white
        
     //   print(indexPath)
     //   print(IndexPath())
     //   print(indexPath.row)
       // print("_____", calendario.indexPathsForSelectedItems)
        
       // var indice = calendario.indexPathsForSelectedItems
        
                
        if cell.dias.text == String(cita.dia)  {
            
            if cita.disponible == false {

      cell.backgroundColor = UIColor.orange
                
            } else {
                 cell.backgroundColor = UIColor.white
            }

      }

  /*      else{
            if nuevaCita[indexPath.row].disponible == false{
                
                if cell.dias.text == String(cita.dia)  {
                    
                    cell.backgroundColor = UIColor.red
                    
                }
                
            }
            
        } */
    
        
       //print("----\(indice)------------------------")
        
        return cell
        
        
        
    }
    
    

}
